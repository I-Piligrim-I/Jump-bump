

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class JumpBump extends Hitable {
	static Level l;
	static BufferedImage Rabbit;
	static int w;
	static int h;


	static class JandB extends JPanel {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		protected void paintComponent(Graphics arg0) {
			super.paintComponent(arg0);
			Graphics2D g2d = (Graphics2D) arg0;
			w = getWidth();
			h = getHeight();
			int XX;
			int YY;
			for (int i = 0; i < Level.drawable.size(); i++) {
				Level.drawable.get(i).draw(g2d);
			}

		}
	}

	public static void main(String[] args) throws IOException {
		l = new Level("levelText.txt");
		JFrame window = new JFrame("jump'n'bump");
		window.setSize(1500, 1000);
		window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		JPanel JandB = new JandB();
		window.add(JandB);
		JandB.setFocusable(true);
		window.setExtendedState(JFrame.MAXIMIZED_BOTH);
		window.setVisible(true);

		Rabbit = ImageIO.read(new File("C:\\Users\\asus\\Desktop\\Jump'n'Bump\\src\\rabbit.png"));

		JandB.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent arg0) {

			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				for (int i = 0; i < Level.rabbits.size(); i++) {
					Level.rabbits.get(i).keyreleased(arg0.getKeyCode());
				}

			}

			@Override
			public void keyPressed(KeyEvent arg0) {
				for (int i = 0; i < Level.rabbits.size(); i++) {
					Level.rabbits.get(i).keypressed(arg0.getKeyCode());
				}

			}
		});
		Timer rabbittimer = new Timer(15, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				for (int i = 0; i < Level.rabbits.size(); i++) {
					Level.rabbits.get(i).update();
				}
				window.repaint();
			}
		});
		rabbittimer.start();

	}

}