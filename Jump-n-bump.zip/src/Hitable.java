//Lundina Darya
//18.05.18 (Hittest)
//Jump&Bump

public class Hitable {
	//���������� ������
	double x;
	double y;
	int height;
	int width;
	
	
	int hitTest(double RabX, double RabY, double RabR) {
		int side = 0;
	
		if ((RabX + RabR > x) && (RabX < x + width)) {
			if ((RabY <= y) && (RabY + RabR >= y)) {
				side = 1;
			}
			if ((RabY <= y + height) && (RabY + RabR >= y + height)) {
				side = 3;
			}
		} else {
			if ((RabY + RabR > y) && (RabY < y + height)) {
				if ((RabX <= x) && (RabX + RabR >= x - 4)) {
					side = 4;
				}
				if ((RabX <= x + width + 4) && (RabX + RabR >= x + width)) {
					side = 2;
				}
			}
			if (((RabY + RabR) > JumpBump.h)) {
				side = 1;
			}
			if ((RabY < 0)) {
				side = 3;
			}
			if (((RabX + RabR) > JumpBump.w)) {
				side = 4;
			}
			if (((RabX) < 0)) {
				side = 2;
			}


		}		
		
		return side;
		

	}

}
