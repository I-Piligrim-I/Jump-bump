
//Lundina Darya
//18.05.18 (���� �������)
//Jump&Bump

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class Rabbit extends Hitable implements Drawable {
	double vx;
	double vy;
	double Vxconst = 5;
	double Vyconst = -7.69;
	double Vychange = 0.14;
	int keyleft;
	int keyright;
	int keyup;
	int score;
	String Number; 
	static final int size = 70;
	Random r = new Random();
	BufferedImage image;

	boolean isUpPushed = false;
	boolean isDownPushed = false;
	boolean isLeftPushed = false;
	boolean isRightPushed = false;
	
	static double X;
	static double Y;

	Rabbit(int _left, int _up, int _right, int X, String filename, String number) throws IOException {
		keyleft = _left;
		keyup = _up;
		keyright = _right;
		width = size;
		height = size;
		x = X;
		image = ImageIO.read(new File(filename));
		Number = number;
		
	}

	void keyreleased(int key) {
		if (key == keyleft) {
			vx = 0;

		}
		if (key == keyright) {
			vx = 0;
		}

	}

	void keypressed(int key) {
		if ((key == keyleft) && (isLeftPushed == false)) {
			vx = -Vxconst;
		}
		if ((key == keyright) && (isRightPushed == false)) {
			vx = Vxconst;
		}
		if ((key == keyup) && (isUpPushed == false) && (isDownPushed == true)) {
			vy = Vyconst;

		}

	}

	public void update() {
		isUpPushed = false;
		isDownPushed = false;
		isLeftPushed = false;
		isRightPushed = false;
		for (int i = 0; i < Level.allhitable.size(); i++) {
			if (Level.allhitable.get(i) != this) {
				if (((Level.allhitable.get(i).hitTest(x, y, size) == 1) && (vy >= 0)) ) {
					isDownPushed = true;
					if (Level.allhitable.get(i).getClass() == Rabbit.class) {
						Level.allhitable.get(i).x = 0;
						Level.allhitable.get(i).y = 0;
						score = score + 1;
					}

				}
				if (((Level.allhitable.get(i).hitTest(x, y, size) == 2) && (vx <= 0))) {
					isLeftPushed = true;
				}
				if (((Level.allhitable.get(i).hitTest(x, y, size) == 3) && (vy <= 0)) ) {
					isUpPushed = true;
				}
				if (((Level.allhitable.get(i).hitTest(x, y, size) == 4) && (vx >= 0))) {
					isRightPushed = true;
				}
			}
		}

		if ((isDownPushed == true)) {
			vy = 0;
		} else {
			if (isUpPushed == true) {
				vy = -vy;
			}
			vy = vy + Vychange;
			y = y + vy;
		}
		if ((isLeftPushed == true) && (vx <= 0)) {
			vx = 0;
		}
		if ((isRightPushed == true) && (vx >= 0)) {
			vx = 0;
		}
		x = x + vx;

	}

	public void draw(Graphics2D g2d) {
		g2d.drawImage(image, (int) x, (int) y, size, size,  null);
		Font font = new Font("Courier New", Font.BOLD, 15);
		g2d.setFont(font);
		g2d.setColor(new Color( 152, 92, 255));
		g2d.drawString(Number, (int)x, (int)(y+size/4));
	}
}