

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;



public class Level {
	/**
	 * create ArrayLists
	 */
	
	static ArrayList<Wall> block = new ArrayList<Wall>();
	static ArrayList<Rabbit> rabbits = new ArrayList<Rabbit>();
	static ArrayList<Drawable> drawable = new ArrayList<Drawable>();
	static ArrayList<Hitable> allhitable = new ArrayList<Hitable>();
	
	static BufferedImage Field;

	Level(String filename) throws IOException {
		
		
		Scanner sc = new Scanner(new File("C:\\Users\\asus\\Desktop\\Jump'n'Bump\\src\\levelText.txt"));
		int BlocksNumber = sc.nextInt();
		for (int i = 0; i < BlocksNumber; i++) {
			block.add(new Wall(sc.nextInt(), sc.nextInt(), sc.nextInt(), sc.nextInt()));
		}
		sc.close();
		Field = ImageIO.read(new File("C:\\Users\\asus\\Desktop\\Jump'n'Bump\\src\\���2.jpg"));
		BackGround background = new BackGround();
		Score score = new Score();
		Scanner scan = new Scanner(new File("C:\\Users\\asus\\Desktop\\Jump'n'Bump\\src\\rabbitTest.txt"));
		int NumberOfRabbits = scan.nextInt();
		for (int i = 0; i < NumberOfRabbits; i++) {
			rabbits.add(new Rabbit(
					scan.nextInt(),
					scan.nextInt(),  
					scan.nextInt(),
					scan.nextInt(),
					scan.next(),
					scan.next())
			);
		}
		scan.close();
		
		
		drawable.add(background);
		allhitable.addAll(block);
		drawable.addAll(block);
		allhitable.addAll(rabbits);
		drawable.addAll(rabbits);
		drawable.add(score);
		
		
		
		
	}

}