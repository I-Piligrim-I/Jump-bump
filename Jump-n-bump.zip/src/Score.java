import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class Score implements Drawable {

	public Color scoreColor = Color.BLACK;

	@Override
	public void draw(Graphics2D g2d) {
		int j = 40;
		int i = 1;
		for (Rabbit r : JumpBump.l.rabbits) {
			g2d.setColor(scoreColor);
			g2d.setFont(new Font("Courier New", 1, 20));
			g2d.drawString("rabbit" +" " + Integer.toString(i) +" - "+ Integer.toString(r.score), JumpBump.w/2, j);
			i = i + 1;
			j = j + 20;
		}

	}


}
