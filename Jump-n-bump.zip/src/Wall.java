//Lundina Darya
//18.05.18 (�����)
//Jump&Bump

import java.awt.Color;
import java.awt.Graphics2D;

public class Wall extends Hitable implements Drawable{

	Wall(int X, int Y, int w, int h) {
		x = X;
		y = Y;
		width = w;
		height = h;
	}

	public void draw(Graphics2D g2d) {
		g2d.setColor(new Color(000, 000, 000));
		g2d.drawRect((int)x, (int)y, width, height);
		g2d.setColor(new Color(255, 255, 255));
		g2d.drawRect((int)x+1, (int)y+1, width-2, height-2);
	}
	
}
