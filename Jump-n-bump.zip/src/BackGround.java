import java.awt.Color;
import java.awt.Graphics2D;

public class BackGround implements Drawable {
	static final Color backgroundColor = Color.BLUE;

	@Override
	public void draw(Graphics2D g) {
		// TODO Auto-generated method stub
		g.drawImage(JumpBump.l.Field, 0, 0, null);
		
	}

}
